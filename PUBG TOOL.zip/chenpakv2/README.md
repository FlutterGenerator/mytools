# chenpakv2

cd chenpakv2
./chenpak.sh