Telegram:https://t.me/+R9KoDxIuEQYxNmZl

# PUBG-PASTER 
This PAKtool is created to modify the PUBG Mobile PAK files

## Installing
1. Install Termux from PlayStore,
2. Open the Termux App and wait for the installation process,
3. Enter This Command:
```

termux-setup-storage



pkg update && pkg upgrade



pkg install git

```

4. Clone this repository
5. 
```
git clone https://github.com/Pubg-paster/Pubg-paster.git
```
5. Open ThePAK directory and run setup.
```
cd Pubg-paster



chmod +x setup



bash setup

```
6. Done.

##:USAGE:
type in termux following commands 

cd Pubg-paster

bash thepak

  

