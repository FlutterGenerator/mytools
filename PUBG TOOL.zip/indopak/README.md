# Indopak
Indopak
## Installing
1. Install Termux from PlayStore,
2. Open the Termux App and wait for the installation process,
3. Enter This Command:
```
termux-setup-storage
pkg update
pkg upgrade
pkg install git
```
4. Clone this repository
```
git clone https://github.com/djalolovtk/indopak
```
5. Open ThePAK directory and run setup.
```
cd indopak
bash install
```
6. Done.
